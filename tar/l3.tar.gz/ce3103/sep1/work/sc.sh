#!/bin/bash


function f1
{ 
	echo "hello world"
}

echo "one"
f1

echo "two"
