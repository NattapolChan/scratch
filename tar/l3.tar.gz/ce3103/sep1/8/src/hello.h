void helloprint(void);
void helloworld(int* count);
