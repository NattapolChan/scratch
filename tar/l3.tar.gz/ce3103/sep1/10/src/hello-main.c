#include <stdio.h>
#include "hello.h"
#include <unistd.h>

int main() {

	printf("Hello world from main!\n");

	helloprint();
	sleep(10);
	helloworld();

	printf("\nBYE!\n");
	return 0;
}
