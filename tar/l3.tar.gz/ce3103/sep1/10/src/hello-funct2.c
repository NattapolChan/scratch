#include <stdio.h>
#include "hello.h"

void helloworld(void) {
	printf("HEllo from function 2 \n");
}
