#include <stdio.h>

void helloprint(void){
	printf("Hello world from funct1!\n");
}
