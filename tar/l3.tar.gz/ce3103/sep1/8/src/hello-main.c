#include <stdio.h>
#include "hello.h"

int main() {
	int count = 0;
	helloprint();
	while(1) 
		helloworld(&count);
}
