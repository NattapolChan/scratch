#include <stdio.h>
#include "hello.h"

void helloworld(int* count) {
	char i, c;
	i = fread(&c, 1, 1, stdin);
	if (i>0) fwrite(&c, 1, 1, stdout);
	*count++;
}
